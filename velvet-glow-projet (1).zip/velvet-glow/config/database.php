<?php

// Informations de connexion à MySQL
$hote = "localhost";
$base = "velvet_glow";
$utilisateur = "root";
$motDePasse = "";

// Connexion à la base de données avec PDO
try {
    $pdo = new PDO(
        "mysql:host=$hote;dbname=$base;charset=utf8mb4",
        $utilisateur,
        $motDePasse
    );

    // Afficher les erreurs SQL pendant le développement
    $pdo->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

} catch (PDOException $e) {
    // Ne pas afficher les détails techniques aux visiteurs
    error_log($e->getMessage());
    die("Erreur de connexion à la base de données.");
}
