<?php

// Sécuriser les textes avant de les afficher dans une page HTML.
function securiser($texte) {
    return htmlspecialchars((string) $texte, ENT_QUOTES, "UTF-8");
}
