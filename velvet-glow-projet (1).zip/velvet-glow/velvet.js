document.addEventListener("DOMContentLoaded", function () {

    // =========================================
    // 1. ÉLÉMENTS DE LA PAGE
    // =========================================

    const boutonExplorer = document.querySelector(".btn-gold");
    const sectionProduits = document.querySelector(".products");
    const categories = document.querySelectorAll(".category");
    const produits = document.querySelectorAll(".product-card");

    // Bouton "Explore Collection"
    if (boutonExplorer && sectionProduits) {
        boutonExplorer.addEventListener("click", function () {
            sectionProduits.scrollIntoView({
                behavior: "smooth"
            });
        });
    }

    // =========================================
    // 2. CATÉGORIES DE L'ACCUEIL
    // =========================================

    let categorieSelectionnee = "";

    categories.forEach(function (categorie) {

        categorie.addEventListener("click", function () {

            const elementNom = categorie.querySelector(".category-name");

            if (!elementNom) {
                return;
            }

            const nomCategorie = elementNom.textContent
                .trim()
                .toLowerCase()
                .replace(/\s+/g, "-");

            if (categorieSelectionnee === nomCategorie) {
                categorieSelectionnee = "";
            } else {
                categorieSelectionnee = nomCategorie;
            }

            produits.forEach(function (produit) {

                if (
                    categorieSelectionnee === "" ||
                    produit.dataset.category === categorieSelectionnee
                ) {
                    produit.style.display = "";
                } else {
                    produit.style.display = "none";
                }

            });
        });
    });

    // =========================================
    // 3. FAVORIS
    // =========================================

    produits.forEach(function (produit) {

        if (produit.querySelector(".favorite-btn")) {
            return;
        }

        const boutonFavori = document.createElement("button");

        boutonFavori.className = "favorite-btn";
        boutonFavori.type = "button";
        boutonFavori.textContent = "♡";

        boutonFavori.setAttribute(
            "aria-label",
            "Ajouter aux favoris"
        );

        produit.appendChild(boutonFavori);

        boutonFavori.addEventListener("click", function () {

            const estFavori = boutonFavori.classList.toggle("active");

            boutonFavori.textContent = estFavori ? "♥" : "♡";

            boutonFavori.setAttribute(
                "aria-label",
                estFavori
                    ? "Retirer des favoris"
                    : "Ajouter aux favoris"
            );

        });
    });

    // =========================================
    // 4. CONFIGURATION DU PANIER
    // =========================================

    const utiliserPHP =
        window.location.protocol === "http:" ||
        window.location.protocol === "https:";

    let panier = [];
    let panierPret = !utiliserPHP;
    let operationEnCours = false;

    const compteurPanier = document.querySelector("#cart-count");
    const listePanier = document.querySelector("#liste-panier");
    const totalPanier = document.querySelector("#total-panier");

    // En mode fichier local, utiliser localStorage.
    // En mode localhost, utiliser les sessions PHP.

    if (!utiliserPHP) {

        try {
            panier = JSON.parse(
                localStorage.getItem("velvetPanier") || "[]"
            );

            if (!Array.isArray(panier)) {
                panier = [];
            }

        } catch (erreur) {
            panier = [];
        }
    }

    // =========================================
    // 5. SAUVEGARDE LOCALE
    // =========================================

    function sauvegarderPanier() {

        if (!utiliserPHP) {
            localStorage.setItem(
                "velvetPanier",
                JSON.stringify(panier)
            );
        }
    }

    // =========================================
    // 6. RÉCUPÉRATION DU PANIER PHP
    // =========================================

    function mettreAJourDepuisPHP(resultat) {

        if (!resultat || !Array.isArray(resultat.articles)) {
            throw new Error("Réponse du panier invalide.");
        }

        panier = resultat.articles.map(function (article) {

            return {
                id: article.id,
                nom: article.nom,
                prix: Number(article.prix),
                quantite: Number(article.quantite)
            };

        });

        afficherPanier();
    }

    // =========================================
    // 7. COMMUNICATION AVEC PHP
    // =========================================

    function demanderPanierPHP(donnees) {

        const options = {};

        if (donnees) {
            options.method = "POST";
            options.body = donnees;
        } else {
            options.method = "GET";
        }

        return fetch("api/panier.php", options)

            .then(function (reponse) {

                if (!reponse.ok) {
                    throw new Error(
                        "Le serveur PHP a refusé la demande."
                    );
                }

                return reponse.json();
            })

            .then(function (resultat) {

                if (resultat.erreur) {
                    throw new Error(resultat.erreur);
                }

                mettreAJourDepuisPHP(resultat);

                return resultat;
            });
    }

    // =========================================
    // 8. AFFICHAGE DU PANIER
    // =========================================

    function afficherPanier() {

        let nombreArticles = 0;
        let total = 0;

        // Vider proprement l'affichage sans innerHTML.
        if (listePanier) {
            listePanier.replaceChildren();
        }

        panier.forEach(function (article, index) {

            const quantite = Number(article.quantite) || 1;
            const prix = Number(article.prix);

            nombreArticles += quantite;
            total += prix * quantite;

            if (!listePanier) {
                return;
            }

            // Créer un élément HTML sans injecter de code HTML.
            const ligne = document.createElement("li");

            ligne.textContent =
                article.nom + " - " +
                prix.toFixed(2) + " $" +
                (quantite > 1 ? " x " + quantite : "") +
                " ";

            // Bouton pour supprimer un produit.
            const supprimer = document.createElement("button");

            supprimer.type = "button";
            supprimer.textContent = "Supprimer";

            supprimer.disabled =
                operationEnCours || !panierPret;

            supprimer.addEventListener("click", function () {

                if (operationEnCours || !panierPret) {
                    return;
                }

                if (utiliserPHP) {

                    // Supprimer le produit dans la session PHP.
                    operationEnCours = true;
                    afficherPanier();

                    const donnees = new URLSearchParams();

                    donnees.append("action", "supprimer");
                    donnees.append("id", article.id);

                    demanderPanierPHP(donnees)

                        .catch(function (erreur) {

                            alert(
                                "Suppression impossible : " +
                                erreur.message
                            );
                        })

                        .finally(function () {

                            operationEnCours = false;
                            afficherPanier();

                        });

                } else {

                    // Suppression en mode local.
                    panier.splice(index, 1);

                    sauvegarderPanier();
                    afficherPanier();
                }
            });

            ligne.appendChild(supprimer);
            listePanier.appendChild(ligne);

        });

        // Actualiser le nombre de produits.
        if (compteurPanier) {
            compteurPanier.textContent = nombreArticles;
        }

        // Actualiser le prix total.
        if (totalPanier) {
            totalPanier.textContent = total.toFixed(2);
        }
    }

    // =========================================
    // 9. BOUTONS AJOUTER AU PANIER
    // =========================================

    const boutonsPanier = [];

    produits.forEach(function (produit) {

        let bouton = produit.querySelector(".add-to-cart");

        if (!bouton) {

            bouton = document.createElement("button");

            bouton.type = "button";
            bouton.className = "add-to-cart";
            bouton.textContent = "Ajouter au panier";

            produit.appendChild(bouton);
        }

        boutonsPanier.push(bouton);

        bouton.addEventListener("click", function () {

            if (!panierPret || operationEnCours) {
                return;
            }

            const elementNom = produit.querySelector(".product-name");

            if (!elementNom) {
                return;
            }

            const article = {
                id: produit.dataset.id,
                nom: elementNom.textContent.trim(),
                prix: Number(produit.dataset.price)
            };

            // Vérifier l'identifiant.
            if (
                !Number.isInteger(Number(article.id)) ||
                Number(article.id) <= 0
            ) {
                alert("Identifiant du produit invalide.");
                return;
            }

            if (utiliserPHP) {

                // Ajout avec une requête POST vers PHP.
                operationEnCours = true;
                mettreAJourBoutons();

                const donnees = new URLSearchParams();

                donnees.append("action", "ajouter");
                donnees.append("id", article.id);

                demanderPanierPHP(donnees)

                    .then(function () {

                        alert(
                            article.nom + " ajouté au panier !"
                        );

                    })

                    .catch(function (erreur) {

                        alert(
                            "Ajout impossible : " +
                            erreur.message
                        );

                    })

                    .finally(function () {

                        operationEnCours = false;
                        mettreAJourBoutons();

                    });

            } else {

                // Ajout en mode local.
                if (
                    !Number.isFinite(article.prix) ||
                    article.prix < 0
                ) {
                    alert("Prix du produit invalide.");
                    return;
                }

                panier.push(article);

                sauvegarderPanier();
                afficherPanier();

                alert(
                    article.nom + " ajouté au panier !"
                );
            }
        });
    });

    // =========================================
    // 10. ACTUALISATION DES BOUTONS
    // =========================================

    function mettreAJourBoutons() {

        boutonsPanier.forEach(function (bouton) {
            bouton.disabled = !panierPret || operationEnCours;
        });

        // Important : actualiser également le bouton Supprimer.
        afficherPanier();
    }

    // =========================================
    // 11. OUVERTURE DU MINI-PANIER
    // =========================================

    const boutonShopping = document.querySelector("#cart-toggle");
    const miniPanier = document.querySelector("#mini-panier");
    const boutonFermer = document.querySelector("#fermer-panier");

    if (boutonShopping && miniPanier) {

        boutonShopping.addEventListener("click", function () {
            miniPanier.hidden = false;
        });
    }

    if (boutonFermer && miniPanier) {

        boutonFermer.addEventListener("click", function () {
            miniPanier.hidden = true;
        });
    }

    // =========================================
    // 12. INITIALISATION DU PANIER
    // =========================================

    if (utiliserPHP) {

        mettreAJourBoutons();

        demanderPanierPHP()

            .then(function () {

                panierPret = true;
                mettreAJourBoutons();

            })

            .catch(function (erreur) {

                console.error(
                    "Panier PHP indisponible :",
                    erreur
                );

                alert(
                    "Le panier PHP est indisponible. " +
                    "Vérifie Apache et MySQL (XAMPP ou WampServer)."
                );

            });

    } else {

        afficherPanier();
        mettreAJourBoutons();

    }

    // =========================================
    // 13. FILTRES DE LA BOUTIQUE
    // =========================================

    const boutonsFiltres = document.querySelectorAll(".filtre-btn");
    const sectionsBoutique = document.querySelectorAll(".variete");

    boutonsFiltres.forEach(function (bouton) {

        bouton.addEventListener("click", function () {

            const filtre = bouton.dataset.filtre;

            boutonsFiltres.forEach(function (autreBouton) {
                autreBouton.classList.remove("active");
            });

            bouton.classList.add("active");

            sectionsBoutique.forEach(function (section) {

                if (
                    filtre === "tout" ||
                    section.dataset.section === filtre
                ) {
                    section.hidden = false;
                } else {
                    section.hidden = true;
                }

            });
        });
    });

    // =========================================
    // 14. RECHERCHE DES PRODUITS
    // =========================================

    const rechercheProduit =
        document.querySelector("#recherche-produit");

    if (rechercheProduit) {

        rechercheProduit.addEventListener("input", function () {

            const recherche = rechercheProduit.value
                .trim()
                .toLowerCase();

            sectionsBoutique.forEach(function (section) {

                let produitTrouve = false;

                section
                    .querySelectorAll(".product-card")
                    .forEach(function (produit) {

                        const elementNom =
                            produit.querySelector(".product-name");

                        if (!elementNom) {
                            return;
                        }

                        const nom = elementNom.textContent.toLowerCase();

                        const correspond = nom.includes(recherche);

                        produit.hidden = !correspond;

                        if (correspond) {
                            produitTrouve = true;
                        }

                    });

                section.hidden = !produitTrouve;
            });

            boutonsFiltres.forEach(function (bouton) {
                bouton.classList.remove("active");
            });

        });
    }

    // =========================================
    // 15. UTILISATEUR CONNECTÉ
    // =========================================

    const lienConnexion = document.querySelector("#lien-connexion");
    const nomUtilisateur = document.querySelector("#nom-utilisateur");
    const formulaireDeconnexion = document.querySelector("#form-deconnexion");

    if (
        lienConnexion &&
        nomUtilisateur &&
        formulaireDeconnexion &&
        utiliserPHP
    ) {

        fetch("api/utilisateur.php")

            .then(function (reponse) {

                if (!reponse.ok) {
                    throw new Error("Erreur du serveur.");
                }

                return reponse.json();
            })

            .then(function (utilisateur) {

                if (utilisateur.connecte) {

                    lienConnexion.hidden = true;

                    // textContent protège l'affichage du nom.
                    nomUtilisateur.textContent =
                        "Bonjour " + utilisateur.nom;

                    nomUtilisateur.hidden = false;
                    formulaireDeconnexion.hidden = false;

                } else {

                    lienConnexion.hidden = false;
                    nomUtilisateur.hidden = true;
                    formulaireDeconnexion.hidden = true;
                }

            })

            .catch(function (erreur) {

                console.error(
                    "Vérification utilisateur :",
                    erreur
                );
            });
    }

    // =========================================
    // 16. COMPTEUR DE VISITES PHP
    // =========================================

    if (boutonExplorer && utiliserPHP) {

        fetch("api/visites.php")

            .then(function (reponse) {

                if (!reponse.ok) {
                    throw new Error("Erreur du compteur.");
                }

                return reponse.text();
            })

            .then(function (message) {
                console.log(message);
            })

            .catch(function (erreur) {

                console.error(
                    "Compteur de visites :",
                    erreur
                );
            });
    }

    // =========================================
    // 17. PRODUITS RÉCUPÉRÉS DEPUIS MYSQL
    // =========================================

    if (utiliserPHP) {

        fetch("api/produits.php")

            .then(function (reponse) {

                if (!reponse.ok) {
                    throw new Error("Erreur du serveur.");
                }

                return reponse.json();
            })

            .then(function (resultat) {

                if (!resultat || !Array.isArray(resultat.produits)) {
                    throw new Error("Liste de produits invalide.");
                }

                resultat.produits.forEach(function (article) {

                    // Retrouver le produit correspondant dans la page.
                    const carte = document.querySelector(
                        '.product-card[data-id="' + article.id + '"]'
                    );

                    if (carte) {

                        // Le prix provient de la base MySQL.
                        carte.dataset.price = article.prix;

                        const nom = carte.querySelector(".product-name");

                        if (nom) {
                            // Ne pas interpréter le nom comme du HTML.
                            nom.textContent = article.nom;
                        }
                    }

                });

            })

            .catch(function (erreur) {

                console.error(
                    "Chargement des produits :",
                    erreur
                );
            });
    }

});
