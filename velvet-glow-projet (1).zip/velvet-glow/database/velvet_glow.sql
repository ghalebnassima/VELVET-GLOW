-- ==========================================================
-- VELVET GLOW - BASE DE DONNEES PRINCIPALE
-- Projet PHP / MySQL
-- ==========================================================

-- Creer la base de donnees si elle n'existe pas.
CREATE DATABASE IF NOT EXISTS `velvet_glow`
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

-- Selectionner la base de donnees.
USE `velvet_glow`;

-- ==========================================================
-- TABLE PRODUITS
-- ==========================================================

CREATE TABLE `produits` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `nom` VARCHAR(150) NOT NULL,
    `categorie` VARCHAR(50) NOT NULL,
    `prix` DECIMAL(10,2) NOT NULL,
    `image_url` TEXT DEFAULT NULL,

    PRIMARY KEY (`id`)
) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci;

-- Inserer les 30 produits du catalogue.
INSERT INTO `produits`
    (`id`, `nom`, `categorie`, `prix`, `image_url`)
VALUES
(1, 'Velvet Matte Lipstick', 'lip-gloss', 38.00, NULL),
(2, 'Flawless Foundation Bottle', 'foundation', 38.00, NULL),
(3, 'Luminous Face Cream', 'skincare', 38.00, NULL),
(4, 'Precision Liquid Eyeliner', 'eyeliner', 38.00, NULL),
(5, 'Cream Glow Serum', 'serum', 38.00, NULL),
(6, 'Ultra-Shine Lip Gloss', 'lip-gloss', 38.00, NULL),
(7, 'Color 12', 'lipstick', 24.00, NULL),
(8, 'Color 24', 'lipstick', 24.00, NULL),
(9, 'Lipstick 052', 'lipstick', 24.00, NULL),
(10, 'Lipstick 11', 'lipstick', 24.00, NULL),
(11, 'Claire', 'foundation', 22.00, NULL),
(12, 'White', 'foundation', 22.00, NULL),
(13, 'Chocolat', 'foundation', 22.00, NULL),
(14, 'Dark Skin', 'foundation', 22.00, NULL),
(15, 'Perfecting Cream', 'cream', 20.00, NULL),
(16, 'Skin Glow', 'cream', 20.00, NULL),
(17, 'All Skin', 'cream', 20.00, NULL),
(18, 'Glow Face', 'cream', 20.00, NULL),
(19, 'Crayon Eyeliner Rouge', 'eyeliner', 15.00, NULL),
(20, 'Feutre Eyeliner Rose', 'eyeliner', 15.00, NULL),
(21, 'Feutre Eyeliner Marron', 'eyeliner', 15.00, NULL),
(22, 'Feutre Eyeliner Noir', 'eyeliner', 15.00, NULL),
(23, 'Hydratant', 'serum', 23.00, NULL),
(24, 'Routine', 'serum', 23.00, NULL),
(25, 'Primary Serum', 'serum', 23.00, NULL),
(26, 'Enrich Serum', 'serum', 23.00, NULL),
(27, 'Lipgloss 024', 'gloss', 10.00, NULL),
(28, 'Lipgloss 019', 'gloss', 10.00, NULL),
(29, 'Lipgloss 016', 'gloss', 10.00, NULL),
(30, 'Bombe Lipgloss', 'gloss', 10.00, NULL);

-- ==========================================================
-- TABLE UTILISATEURS
-- ==========================================================

CREATE TABLE `utilisateurs` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `nom` VARCHAR(100) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `mot_de_passe` VARCHAR(255) NOT NULL,
    `date_creation` TIMESTAMP NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (`id`),
    UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci;

-- Aucun utilisateur personnel n'est inclus.
-- Les comptes seront crees avec le formulaire PHP.
