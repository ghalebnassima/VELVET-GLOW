<?php
session_start();

// Vérifier que l'utilisateur est connecté.
if (!isset($_SESSION["utilisateur_id"])) {
    header("Location: shopping.html");
    exit;
}

// Créer les jetons de sécurité des formulaires.
if (empty($_SESSION["csrf_suppression"])) {
    $_SESSION["csrf_suppression"] = bin2hex(random_bytes(32));
}

if (empty($_SESSION["csrf_modification"])) {
    $_SESSION["csrf_modification"] = bin2hex(random_bytes(32));
}

// Importer la connexion PDO et les fonctions communes.
require_once __DIR__ . "/config/database.php";
require_once __DIR__ . "/config/fonctions.php";

// Récupérer les informations de l'utilisateur connecté.
$sql = "SELECT id, nom, email, date_creation
        FROM utilisateurs
        WHERE id = ?";

$requete = $pdo->prepare($sql);
$requete->execute([(int) $_SESSION["utilisateur_id"]]);
$utilisateur = $requete->fetch(PDO::FETCH_ASSOC);

if (!$utilisateur) {
    unset($_SESSION["utilisateur_id"], $_SESSION["utilisateur_nom"]);
    header("Location: shopping.html");
    exit;
}

// Formater la date d'inscription.
$dateInscription = date(
    "d/m/Y",
    strtotime($utilisateur["date_creation"])
);

// Manipulation des chaînes de caractères.
$messageBienvenue = "Bienvenue, " . $utilisateur["nom"] . " !";

// Recherche du caractère @ dans l'adresse email.
$positionArobase = strpos($utilisateur["email"], "@");

// Découpage de l'email pour récupérer le domaine.
$domaineEmail = "";

if ($positionArobase !== false) {
    $partiesEmail = explode("@", $utilisateur["email"]);
    $domaineEmail = $partiesEmail[1] ?? "";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon compte - Velvet Glow</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #fff7f9;
            padding: 40px;
        }

        main {
            max-width: 600px;
            margin: 40px auto;
            padding: 30px;
            background: white;
            border: 1px solid #e8d8dd;
            border-radius: 12px;
        }

        a {
            color: #a34b6b;
        }

        input, button {
            padding: 7px;
            margin-top: 8px;
        }

        hr {
            margin: 20px 0;
        }
    </style>
</head>

<body>
    <main>
        <h1>Mon compte Velvet Glow</h1>

        <p><?= securiser($messageBienvenue) ?></p>

        <p>
            <strong>Domaine de votre email :</strong>
            <?= securiser($domaineEmail) ?>
        </p>

        <p>
            <strong>Nom :</strong>
            <?= securiser($utilisateur["nom"]) ?>
        </p>

        <p>
            <strong>Email :</strong>
            <?= securiser($utilisateur["email"]) ?>
        </p>

        <p>
            <strong>Inscription :</strong>
            <?= securiser($dateInscription) ?>
        </p>

        <h2>Modifier mes informations</h2>

        <form action="api/modifier_compte.php" method="post">
            <input
                type="hidden"
                name="csrf_token"
                value="<?= securiser($_SESSION["csrf_modification"]) ?>"
            >

            <label for="nom">Nouveau nom :</label>

            <input
                type="text"
                id="nom"
                name="nom"
                maxlength="100"
                required
                value="<?= securiser($utilisateur["nom"]) ?>"
            >

            <button type="submit">
                Enregistrer les modifications
            </button>
        </form>

        <hr>

        <h2>Supprimer mon compte</h2>

        <p>
            Attention : cette action supprimera définitivement
            votre compte.
        </p>

        <form
            action="api/supprimer_compte.php"
            method="post"
            onsubmit="return confirm('Voulez-vous vraiment supprimer votre compte ?');"
        >
            <input
                type="hidden"
                name="csrf_token"
                value="<?= securiser($_SESSION["csrf_suppression"]) ?>"
            >

            <label for="password-suppression">
                Confirmer votre mot de passe :
            </label>

            <input
                type="password"
                id="password-suppression"
                name="password"
                autocomplete="current-password"
                required
            >

            <button type="submit">
                Supprimer définitivement mon compte
            </button>
        </form>

        <hr>

        <a href="acceuil.html">Retour à l'accueil</a>
    </main>
</body>
</html>
