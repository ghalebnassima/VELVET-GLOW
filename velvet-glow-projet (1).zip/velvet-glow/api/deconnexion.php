<?php

// Démarrer la session
session_start();

// Autoriser uniquement les requêtes POST
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    http_response_code(405);
    exit("Méthode non autorisée.");
}

// Supprimer les informations de connexion
unset($_SESSION["utilisateur_id"]);
unset($_SESSION["utilisateur_nom"]);

// Retourner à la page de connexion
header("Location: ../shopping.html");
exit;
