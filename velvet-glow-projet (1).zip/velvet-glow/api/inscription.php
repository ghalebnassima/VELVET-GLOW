<?php

// Accepter uniquement les formulaires POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Méthode non autorisée.");
}

// Connexion PDO à MySQL.
require_once __DIR__ . "/../config/database.php";

// Récupérer les données du formulaire.
$nom = $_POST["nom"] ?? "";
$email = $_POST["email"] ?? "";
$motDePasse = $_POST["password"] ?? "";

// Vérifier que les données sont des chaînes.
if (
    !is_string($nom) ||
    !is_string($email) ||
    !is_string($motDePasse)
) {
    http_response_code(400);
    exit("Données invalides.");
}

$nom = trim($nom);
$email = trim($email);

// Vérifier les champs obligatoires.
if ($nom === "" || $email === "" || $motDePasse === "") {
    http_response_code(400);
    exit("Tous les champs sont obligatoires.");
}

// Vérifier la longueur du nom.
if (mb_strlen($nom, "UTF-8") > 100) {
    http_response_code(400);
    exit("Le nom ne doit pas dépasser 100 caractères.");
}

// Vérifier l'adresse email.
if (
    strlen($email) > 255 ||
    !filter_var($email, FILTER_VALIDATE_EMAIL)
) {
    http_response_code(400);
    exit("Adresse email invalide.");
}

// Vérifier le mot de passe.
if (strlen($motDePasse) < 8) {
    http_response_code(400);
    exit("Le mot de passe doit contenir au moins 8 caractères.");
}

// Vérifier si l'email existe déjà.
$requete = $pdo->prepare(
    "SELECT id FROM utilisateurs WHERE email = ?"
);
$requete->execute([$email]);

if ($requete->fetch()) {
    http_response_code(409);
    exit("Cette adresse email est déjà utilisée.");
}

// Hacher le mot de passe avant de l'enregistrer.
$motDePasseProtege = password_hash(
    $motDePasse,
    PASSWORD_DEFAULT
);

// Enregistrer l'utilisateur dans MySQL.
try {
    $requete = $pdo->prepare(
        "INSERT INTO utilisateurs (nom, email, mot_de_passe)
         VALUES (?, ?, ?)"
    );

    $requete->execute([
        $nom,
        $email,
        $motDePasseProtege
    ]);

} catch (PDOException $erreur) {
    // Erreur 23000 : contrainte d'unicité, notamment email déjà utilisé.
    if ($erreur->getCode() === "23000") {
        http_response_code(409);
        exit("Cette adresse email est déjà utilisée.");
    }

    // Ne pas afficher les détails internes de MySQL au visiteur.
    error_log($erreur->getMessage());
    http_response_code(500);
    exit("Une erreur est survenue lors de l'inscription.");
}

// Retourner au formulaire de connexion.
header("Location: ../shopping.html");
exit;
