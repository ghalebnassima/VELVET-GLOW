<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Méthode non autorisée.");
}

if (!isset($_SESSION["utilisateur_id"])) {
    http_response_code(403);
    exit("Vous devez être connecté.");
}
// Vérifier le jeton de sécurité du formulaire.
$jetonSession = $_SESSION["csrf_modification"] ?? "";
$jetonFormulaire = $_POST["csrf_token"] ?? "";

if (
    !is_string($jetonSession) ||
    !is_string($jetonFormulaire) ||
    $jetonSession === "" ||
    !hash_equals($jetonSession, $jetonFormulaire)
) {
    http_response_code(403);
    exit("Formulaire invalide.");
}

require_once __DIR__ . "/../config/database.php";


// Récupérer le nom envoyé par le formulaire.
$nouveauNom = $_POST["nom"] ?? "";

// Vérifier que le nom reçu est bien du texte.
if (!is_string($nouveauNom)) {
    http_response_code(400);
    exit("Nom invalide.");
}

// Supprimer les espaces inutiles.
$nouveauNom = trim($nouveauNom);

// Vérifier la longueur du nom.
if ($nouveauNom === "" || mb_strlen($nouveauNom, "UTF-8") > 100) {
    http_response_code(400);
    exit("Le nom doit contenir entre 1 et 100 caractères.");
}


// UPDATE : modifier l'utilisateur connecté dans MySQL.
$sql = "UPDATE utilisateurs SET nom = :nom WHERE id = :id";
$requete = $pdo->prepare($sql);

$requete->bindValue(":nom", $nouveauNom, PDO::PARAM_STR);
$requete->bindValue(":id", (int) $_SESSION["utilisateur_id"], PDO::PARAM_INT);

$requete->execute();

// Garder la session à jour avec le nouveau nom.
$_SESSION["utilisateur_nom"] = $nouveauNom;

header("Location: ../compte.php");
exit;
