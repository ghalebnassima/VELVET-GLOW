<?php

// Démarrer ou retrouver la session
session_start();

// La réponse sera au format JSON
header("Content-Type: application/json; charset=utf-8");

// Vérifier si un utilisateur est connecté
if (isset($_SESSION["utilisateur_id"])) {

    $reponse = [
        "connecte" => true,
        "nom" => $_SESSION["utilisateur_nom"]
    ];

} else {

    $reponse = [
        "connecte" => false,
        "nom" => ""
    ];
}

// Envoyer la réponse à JavaScript
echo json_encode($reponse);
