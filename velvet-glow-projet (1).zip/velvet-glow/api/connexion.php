<?php
session_start();

// Accepter uniquement les formulaires POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Méthode non autorisée.");
}

// Connexion PDO à MySQL.
require_once __DIR__ . "/../config/database.php";

// Récupérer les informations du formulaire.
$email = $_POST["email"] ?? "";
$motDePasse = $_POST["password"] ?? "";

// Vérifier que les données reçues sont des chaînes.
if (!is_string($email) || !is_string($motDePasse)) {
    http_response_code(400);
    exit("Données invalides.");
}

$email = trim($email);

// Vérifier les champs obligatoires.
if ($email === "" || $motDePasse === "") {
    http_response_code(400);
    exit("Veuillez remplir tous les champs.");
}

// Vérifier le format de l'email.
if (
    strlen($email) > 255 ||
    !filter_var($email, FILTER_VALIDATE_EMAIL)
) {
    http_response_code(400);
    exit("Adresse email invalide.");
}

// Rechercher l'utilisateur dans MySQL.
$requete = $pdo->prepare(
    "SELECT id, nom, mot_de_passe
     FROM utilisateurs
     WHERE email = ?"
);

$requete->execute([$email]);
$utilisateur = $requete->fetch(PDO::FETCH_ASSOC);

// Vérifier le compte et le mot de passe.
if (
    !$utilisateur ||
    !password_verify($motDePasse, $utilisateur["mot_de_passe"])
) {
    http_response_code(401);
    exit("Email ou mot de passe incorrect.");
}

// Renouveler l'identifiant de session.
session_regenerate_id(true);

// Conserver les informations de l'utilisateur connecté.
$_SESSION["utilisateur_id"] = $utilisateur["id"];
$_SESSION["utilisateur_nom"] = $utilisateur["nom"];

// Rediriger vers l'accueil.
header("Location: ../acceuil.html");
exit;
