<?php

// La réponse de PHP sera au format JSON
header("Content-Type: application/json; charset=utf-8");

// On accepte uniquement les requêtes GET
if ($_SERVER["REQUEST_METHOD"] != "GET") {
    http_response_code(405);
    echo json_encode(["erreur" => "Méthode non autorisée"]);
    exit;
}

// Utiliser notre connexion PDO

require_once __DIR__ . "/../config/database.php";


// Fonction pour récupérer tous les produits
function recupererProduits($pdo) {
    $sql = "SELECT id, nom, categorie, prix, image_url
            FROM produits
            ORDER BY id";

    $requete = $pdo->query($sql);

    return $requete->fetchAll(PDO::FETCH_ASSOC);
}

// Appeler notre fonction
$produits = recupererProduits($pdo);

// Envoyer les produits au JavaScript
echo json_encode(["produits" => $produits]);
