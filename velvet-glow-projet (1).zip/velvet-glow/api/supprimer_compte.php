<?php
session_start();

// Accepter uniquement les formulaires POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Méthode non autorisée.");
}

// Vérifier que l'utilisateur est connecté.
if (!isset($_SESSION["utilisateur_id"])) {
    http_response_code(403);
    exit("Vous devez être connecté.");
}

// Vérifier que le formulaire vient de la session utilisateur.
$jetonSession = $_SESSION["csrf_suppression"] ?? "";
$jetonFormulaire = $_POST["csrf_token"] ?? "";


if (
    !is_string($jetonSession) ||
    !is_string($jetonFormulaire) ||
    $jetonSession === "" ||
    !hash_equals($jetonSession, $jetonFormulaire)
) {
    http_response_code(403);
    exit("Formulaire invalide.");
}


require_once __DIR__ . "/../config/database.php";

$motDePasse = $_POST["password"] ?? "";

if (!is_string($motDePasse) || $motDePasse === "") {
    http_response_code(400);
    exit("Le mot de passe est obligatoire.");
}

$idUtilisateur = (int) $_SESSION["utilisateur_id"];

// SELECT : retrouver le mot de passe enregistré.
$requete = $pdo->prepare(
    "SELECT mot_de_passe FROM utilisateurs WHERE id = :id"
);

$requete->bindValue(":id", $idUtilisateur, PDO::PARAM_INT);
$requete->execute();

$utilisateur = $requete->fetch(PDO::FETCH_ASSOC);

if (
    !$utilisateur ||
    !password_verify($motDePasse, $utilisateur["mot_de_passe"])
) {
    http_response_code(403);
    exit("Mot de passe incorrect.");
}

// DELETE : supprimer le compte dans MySQL.
$requete = $pdo->prepare(
    "DELETE FROM utilisateurs WHERE id = :id"
);

$requete->bindValue(":id", $idUtilisateur, PDO::PARAM_INT);
$requete->execute();

// Déconnecter l'utilisateur après la suppression.
$_SESSION = [];
session_regenerate_id(true);

header("Location: ../shopping.html");
exit;
