<?php

// Démarrer la session
session_start();

// Nom du fichier contenant le compteur
$fichier = __DIR__ . "/visites.txt";

// Lire le nombre de visites
if (file_exists($fichier)) {
    $visites = (int) file_get_contents($fichier);
} else {
    $visites = 0;
}

// Compter une seule fois par session
if (!isset($_SESSION["visite_comptee"])) {

    $visites = $visites + 1;

    // Enregistrer le nouveau nombre
    file_put_contents($fichier, $visites, LOCK_EX);

    $_SESSION["visite_comptee"] = true;
}

// Afficher le compteur
echo "Nombre de visites : " . $visites;
