<?php

// Démarrer la session PHP
session_start();

// Envoyer les résultats en JSON
header("Content-Type: application/json; charset=utf-8");

// Connexion à la base MySQL
require_once __DIR__ . "/../config/database.php";

// Créer le panier s'il n'existe pas
if (!isset($_SESSION["panier"])) {
    $_SESSION["panier"] = [];
}

// Ajouter ou supprimer un produit
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $action = $_POST["action"] ?? "";
    $id = filter_input(INPUT_POST, "id", FILTER_VALIDATE_INT);

    if ($id === false || $id === null || $id <= 0) {
        http_response_code(400);
        echo json_encode(["erreur" => "Produit invalide"]);
        exit;
    }

    if ($action == "ajouter") {

        // Vérifier que le produit existe dans MySQL
        $requete = $pdo->prepare(
            "SELECT id FROM produits WHERE id = ?"
        );

        $requete->execute([$id]);

        $produit = $requete->fetch(PDO::FETCH_ASSOC);

        if (!$produit) {
            http_response_code(404);
            echo json_encode(["erreur" => "Produit introuvable"]);
            exit;
        }

        // Ajouter une unité au panier
        if (isset($_SESSION["panier"][$id])) {
            $_SESSION["panier"][$id]++;
        } else {
            $_SESSION["panier"][$id] = 1;
        }

    } elseif ($action == "supprimer") {

        // Retirer le produit du panier
        unset($_SESSION["panier"][$id]);

    } else {
        http_response_code(400);
        echo json_encode(["erreur" => "Action inconnue"]);
        exit;
    }

} elseif ($_SERVER["REQUEST_METHOD"] != "GET") {
    http_response_code(405);
    echo json_encode(["erreur" => "Méthode non autorisée"]);
    exit;
}

// Fonction pour afficher le contenu du panier
function afficherPanier($pdo) {

    $articles = [];
    $total = 0;

    // Parcourir les produits enregistrés dans la session
    foreach ($_SESSION["panier"] as $id => $quantite) {

        $requete = $pdo->prepare(
            "SELECT id, nom, prix FROM produits WHERE id = ?"
        );

        $requete->execute([$id]);
        $produit = $requete->fetch(PDO::FETCH_ASSOC);

        if ($produit) {
            $sousTotal = $produit["prix"] * $quantite;

            $articles[] = [
                "id" => $produit["id"],
                "nom" => $produit["nom"],
                "prix" => $produit["prix"],
                "quantite" => $quantite,
                "sous_total" => $sousTotal
            ];

            $total = $total + $sousTotal;
        }
    }

    return [
        "articles" => $articles,
        "total" => $total
    ];
}

// Envoyer le panier à JavaScript
echo json_encode(afficherPanier($pdo));
