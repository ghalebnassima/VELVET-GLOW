document.addEventListener("DOMContentLoaded", function () {

    // Recuperer les deux parties de la page
    const formulaireConnexion = document.querySelector("#form-connexion");
    const sectionConnexion = formulaireConnexion.closest("section");
    const sectionInscription = document.querySelector("#inscription");

    // Recuperer les liens
    const lienInscription = document.querySelector('a[href="#inscription"]');
    const lienConnexion = document.querySelector('a[href="#form-connexion"]');

    // Afficher l'inscription
    lienInscription.addEventListener("click", function (event) {
        event.preventDefault();

        sectionConnexion.hidden = true;
        sectionInscription.hidden = false;
    });

    // Afficher la connexion
    lienConnexion.addEventListener("click", function (event) {
        event.preventDefault();

        sectionInscription.hidden = true;
        sectionConnexion.hidden = false;
    });

});
